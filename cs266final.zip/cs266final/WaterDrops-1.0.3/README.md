# WaterDrops
Simple UWP app for hydration reminders
